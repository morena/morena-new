<div class="qode-vps-image">
<?php echo get_the_post_thumbnail(get_the_ID(), 'full'); ?>
</div>