<div class="full_screen_section">
    <?php echo bridge_qode_get_module_part( $content ); ?>
</div>
