<?php
require_once BRIDGE_CORE_SHORTCODES_PATH.'/interactive-icon-showcase/functions.php';
require_once BRIDGE_CORE_SHORTCODES_PATH.'/interactive-icon-showcase/interactive-icon-showcase.php';
require_once BRIDGE_CORE_SHORTCODES_PATH.'/interactive-icon-showcase/interactive-icon-showcase-item.php';
