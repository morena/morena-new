<div class="vczapi-my-accounts-purchased-recordings">
    <h3><?php _e( 'Recordings for Purchased Meetings', 'vczapi-woocommerce-addon' ); ?></h3>
    <table class="vczapi-woocommerce-recordings-datatable">
        <thead>
        <tr>
            <th><?php _e( 'Title', 'vczapi-woocommerce-addon' ); ?></th>
            <th><?php _e( 'Date', 'vczapi-woocommerce-addon' ); ?></th>
            <th><?php _e( 'Meeting ID', 'vczapi-woocommerce-addon' ); ?></th>
            <th><?php _e( 'Total Size', 'vczapi-woocommerce-addon' ); ?></th>
            <th><?php _e( 'View', 'vczapi-woocommerce-addon' ); ?></th>
        </tr>
        </thead>
        <tbody>
        </tbody>
    </table>
</div>