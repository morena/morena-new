=== WooCommerce to Zoom ===
* Contributors: northernbeacheswebsites
* Donate link: https://northernbeacheswebsites.com.au/product/donate-to-northern-beaches-websites/
* Tags: woocommerce, zoom
* Requires at least: 4.0
* Requires PHP: 5.2.4
* Tested up to: 5.5.1
* Stable tag: 2.12
* License: GPLv2 or later
* License URI: http://www.gnu.org/licenses/gpl-2.0.html

Connect WooCommerce to Zoom to automatically add attendees to Zoom


== Description ==

Connect WooCommerce to Zoom to automatically add attendees to Zoom


== Installation ==

There are a few options for installing and setting up this plugin.

= Upload Manually =

1. Download and unzip the plugin
2. Upload the 'woocommerce-to-zoom' folder into the '/wp-content/plugins/' directory
3. Go to the Plugins admin page and activate the plugin


== Frequently Asked Questions ==

Please contact us if you need any support: https://northernbeacheswebsites.com.au/support/


== Screenshots ==


== Changelog ==

= 2.12 =
* Support for multiple webinars selection on product edit page

= 2.11 =
* Added option to get webinars from all users on the account

= 2.10 =
* We now validate the email address to make sure it's ok before sending to Zoom

= 2.9 =
* Ability to hide old webinars from showing in the product edit page - see new setting

= 2.8 =
* Added new option to hide checkout form under certain circumstances 

= 2.7 =
* Update to date format in webinar selection on product edit page

= 2.6 =
* We now show registrants on the order view on the My Account screen of WooCommerce

= 2.5 =
* Fix for variation product display in settings

= 2.4 =
* Update to FAQ

= 2.3 =
* Update to FAQ

= 2.2 =
* Ability to auto delete/draft old webinar products

= 2.1 =
* Minor bug fix when both Zoom plugins activated 

= 2.0 =
* If you don't want to sell your webinar and you want to put registration forms on your site, we now have shortcodes and new settings available to achieve this

= 1.17 =
* Saving of additional data to registrant meta

= 1.16 =
* Updates to action sequencing to help with emails

= 1.15 =
* Additional logging added

= 1.14 =
* New button on checkout page which enables you to copy billing details to registration fields to save time

= 1.13 =
* Addition of filters to the checkout page

= 1.12 =
* Minor bug fix

= 1.11 =
* Support for variation products

= 1.10 =
* Bug fixes

= 1.9 =
* New setting to add a list of registrants to the completed order email

= 1.8 =
* New FAQ section on main plugin settings page
* New column on products page which shows webinar ID

= 1.7 =
* Better compatibility with other WooCommerce extensions

= 1.6 =
* Sandbox mode inclusion

= 1.5 =
* Update of authentication URL's to suit meeting plugin - it is advised to re-authenticate after update

= 1.4 =
* We are now going to make the last name compulsory as there were too many errors

= 1.3 =
* Added better support for translation management

= 1.2 =
* Added the ability to clear transients from main plugin page

= 1.1 =
* When deauthorising the plugin remove cached data

= 1.0 =
* Initial launch of the plugin


== Upgrade Notice ==

= 2.12 =
* Support for multiple webinars selection on product edit page

= 2.11 =
* Added option to get webinars from all users on the account

= 2.10 =
* We now validate the email address to make sure it's ok before sending to Zoom

= 2.9 =
* Ability to hide old webinars from showing in the product edit page - see new setting

= 2.8 =
* Added new option to hide checkout form under certain circumstances 

= 2.7 =
* Update to date format in webinar selection on product edit page

= 2.6 =
* We now show registrants on the order view on the My Account screen of WooCommerce

= 2.5 =
* Fix for variation product display in settings

= 2.4 =
* Update to FAQ

= 2.3 =
* Update to FAQ

= 2.2 =
* Ability to auto delete/draft old webinar products

= 2.1 =
* Minor bug fix when both Zoom plugins activated 

= 2.0 =
* If you don't want to sell your webinar and you want to put registration forms on your site, we now have shortcodes and new settings available to achieve this

= 1.17 =
* Saving of additional data to registrant meta

= 1.16 =
* Updates to action sequencing to help with emails

= 1.15 =
* Additional logging added

= 1.14 =
* New button on checkout page which enables you to copy billing details to registration fields to save time

= 1.13 =
* Addition of filters to the checkout page

= 1.12 =
* Minor bug fix

= 1.11 =
* Support for variation products

= 1.10 =
* Bug fixes

= 1.9 =
* New setting to add a list of registrants to the completed order email

= 1.8 =
* New FAQ section on main plugin settings page
* New column on products page which shows webinar ID

= 1.7 =
* Better compatibility with other WooCommerce extensions

= 1.6 =
* Sandbox mode inclusion

= 1.5 =
* Update of authentication URL's to suit meeting plugin - it is advised to re-authenticate after update

= 1.4 =
* We are now going to make the last name compulsory as there were too many errors

= 1.3 =
* Added better support for translation management

= 1.2 =
* Added the ability to clear transients from main plugin page

= 1.1 =
* When deauthorising the plugin remove cached data

= 1.0 =
* Initial launch of the plugin