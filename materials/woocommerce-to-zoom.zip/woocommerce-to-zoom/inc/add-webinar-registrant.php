<?php

    // add_action( 'woocommerce_checkout_update_order_meta', 'woocommerce_to_zoom_add_registrant',999);
    add_action( 'woocommerce_order_status_completed', 'woocommerce_to_zoom_add_registrant',0 );
    
    function woocommerce_to_zoom_add_registrant( $order_id ) {

        //start WooCommerce logging
        $logger = wc_get_logger();
        $context = array( 'source' => 'woocommerce-to-zoom' );
        $logger->info( 'STARTING PROCESSING ORDER: '.$order_id, $context );

        //get order object inc ase we need it
        $order = new WC_Order( $order_id );

        //get the metadata for the order
        $all_post_meta = get_post_meta($order_id);

        foreach($all_post_meta as $meta_key => $meta_value){

            //only proceed for keys which contain zoom_webinar
            if (strpos($meta_key, 'zoom_webinar') !== false) {
                //key looks like: zoom_webinar-217072930-1
                $key_exploded = explode('-',$meta_key);
                $webinar_id = $key_exploded[1];
                $webinar_id = woocommerce_to_zoom_sanitize_webinar_id($webinar_id);

                $meta_value = get_post_meta($order_id,$meta_key,true);

                $body_data_to_json = json_encode($meta_value);

                //register the person for the webinar
                $url = woocommerce_to_zoom_get_api_base().'webinars/'.$webinar_id.'/registrants';

                $access_token = woocommerce_to_zoom_get_access_token();

                $response = wp_remote_post( $url, array(
                    'headers' => array(
                        'Authorization' => 'Bearer '.$access_token,
                        'Content-Type' => 'application/json; charset=utf-8',
                    ),
                    'body' => $body_data_to_json,
                ));

                $status = wp_remote_retrieve_response_code( $response );

                

                if($status == 201){
                    //do something
                    $decodedBody = json_decode(preg_replace('/("\w+"):(\d+(\.\d+)?)/', '\\1:"\\2"', $response['body']), true);
                    $registrant_id = $decodedBody['registrant_id'];
                    $join_url = $decodedBody['join_url'];

                    //lets add meta to the order id
                    if(get_post_meta($order_id,'zoom_registrant_ids',false)){
                        $existing_registrants = get_post_meta($order_id,'zoom_registrant_ids',true);

                        $existing_registrants[$registrant_id] = array(
                            'first_name' => $meta_value['first_name'],
                            'last_name' => $meta_value['last_name'],
                            'email' => $meta_value['email'],
                            'join_url' => $join_url,
                            'webinar_id' => $webinar_id,
                        ); 

                        update_post_meta( $order_id, 'zoom_registrant_ids', $existing_registrants );

                    } else {
                        update_post_meta( $order_id, 'zoom_registrant_ids', array($registrant_id => array(
                            'first_name' => $meta_value['first_name'],
                            'last_name' => $meta_value['last_name'],
                            'email' => $meta_value['email'],
                            'join_url' => $join_url,
                            'webinar_id' => $webinar_id,
                        )));
                    }

                    //we will also log the success
                    $logger->info('USER ADDED TO ZOOM WEBINAR ('.$webinar_id.'): '.$meta_value['first_name'].' '.$meta_value['last_name'],$context);
                    

                } else {
                    //something bad happened
                    $logger->info('URL: '.$url,$context);
                    $logger->info('BODY: '.$body_data_to_json,$context);
                    $logger->info('ACCESS TOKEN: '.$access_token,$context);
                    $logger->info('STATUS: '.$status,$context);

                    if(!is_wp_error($response['body'])){
                        $logger->info('RETURN BODY: '.$response['body'],$context);
                    }

                    
                }

            }
        }   
        

    }

    add_action( 'wp_ajax_zoom_register_user', 'woocommerce_to_zoom_add_registrant_from_form' );
    add_action( 'wp_ajax_nopriv_zoom_register_user', 'woocommerce_to_zoom_add_registrant_from_form' );
    function woocommerce_to_zoom_add_registrant_from_form(){

        $webinar_id = $_POST['webinarId'];
        $json = stripslashes($_POST['json']);

        // echo 'ERROR';
        // wp_die(); 

        // $data = json_decode($json,true);

        //register the person for the webinar
        $url = woocommerce_to_zoom_get_api_base().'webinars/'.$webinar_id.'/registrants';

        $access_token = woocommerce_to_zoom_get_access_token();

        $response = wp_remote_post( $url, array(
            'headers' => array(
                'Authorization' => 'Bearer '.$access_token,
                'Content-Type' => 'application/json; charset=utf-8',
            ),
            'body' => $json,
        ));

        $status = wp_remote_retrieve_response_code( $response );

        if($status == 201){
            //registration page
            $thank_you_page = get_option('wc_settings_zoom_thank_you_page');

            if(strlen($thank_you_page)>0){
                $thank_you_page_link = get_permalink( $thank_you_page );
            } else {
                $thank_you_page_link = get_home_url();    
            }

            echo $thank_you_page_link;
        } else {

            echo 'ERROR';
        }

        
        wp_die(); 

    }

    


?>