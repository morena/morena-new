<?php
/**
* 
*
*
* shortcode for displaying the registration form table
*/
add_shortcode('zoom_registration_table', 'woocommerce_to_zoom_registration_table');

function woocommerce_to_zoom_registration_table($atts){

    //do attributes - currently none - in the future we will look at this
    $attribute = shortcode_atts( array(
        '' => '',
    ), $atts );

    //output styles and scripts
    wp_enqueue_style(array('woocommerce-to-zoom-shortcode-style'));
    wp_enqueue_script(array('woocommerce-to-zoom-shortcode-script','woocommerce-to-zoom-fontawesome'));


    //lets get the upcoming webinars
    $webinars = woocommerce_to_zoom_get_upcoming_webinars_shortcode();

    //process the webinars so we don't show get ones in the past and put them in order
    $webinars_sorted = array();
    $webinars_data = array();
    foreach($webinars as $webinar){

        $timezone = new DateTimeZone($webinar['timezone']);
        $offset   = $timezone->getOffset(new DateTime);
        $webinar_start = date('U',strtotime($webinar['start_time']))+$offset;

        $webinar_id = $webinar['id'];
        $current_time = current_time( 'timestamp' );
        

        if($webinar_start > $current_time){
            $webinars_sorted[$webinar_id] = $webinar_start;
            $webinars_data[$webinar_id] = $webinar;
        }

    }

    //sort the array
    asort($webinars_sorted);
    $good_webinar_list = array();
    foreach($webinars_sorted as $webinar_id => $webinar_start){
        
        array_push($good_webinar_list,$webinars_data[$webinar_id]);
    }


    //registration page
    $registration_page = get_option('wc_settings_zoom_registration_page');

    if(strlen($registration_page)>0){
        $registration_page_link = get_permalink( $registration_page );
    } else {
        $registration_page_link = '#';    
    }


    // var_dump($webinars);

    //start output
    $html = '';

    //start table
    $html .= '<table class="zoom-webinar-table">';

        //do table header
        $html .= '<thead>';
            $html .= '<tr>';
                $html .= '<th>'.__('Topic','woocommerce-to-zoom').'</th>';
                // $html .= '<th>'.__('Date','woocommerce-to-zoom').'</th>';
                $html .= '<th>'.__('Start Time','woocommerce-to-zoom').'</th>';
                $html .= '<th>'.__('Duration','woocommerce-to-zoom').'</th>';
                $html .= '<th>'.__('Register','woocommerce-to-zoom').'</th>';
            $html .= '</tr>';
        $html .= '</thead>';

        //do table body
        $html .= '<tbody>';

            if(count($good_webinar_list)>0){
                //now loop through the webinars
                foreach($good_webinar_list as $webinar){

                    $webinar_id = $webinar['id']; //687492379
                    $webinar_topic = $webinar['topic']; //aka title
                    $webinar_type = $webinar['type']; //5 = webinar,6 = recurrence webinar,9=recurring webinar with fixed time
                    $webinar_duration = $webinar['duration']; //180 in minutes
                    $webinar_timezone = $webinar['timezone']; //America/Los_Angeles
                    $webinar_start = new DateTime($webinar['start_time'], new DateTimeZone('UTC'));
                    $webinar_start->setTimezone(new DateTimeZone($webinar_timezone));
                    $webinar_agenda = $webinar['agenda']; //description

                    

                    //do duration work
                    if(intval($webinar_duration)>60){
                        $hours = intval($webinar_duration)/60;
                        $webinar_duration = $hours.' '.__('hours','woocommerce-to-zoom');
                    } else {
                        $webinar_duration = $webinar_duration.' '.__('minutes','woocommerce-to-zoom');   
                    }

                    //do start
                    $webinar_start_combined = $webinar_start->format(get_option('date_format').' '.get_option('time_format').' T');

                    //do description
                    if(strlen($webinar_agenda)>0){
                        $webinar_topic = $webinar_topic.' <i class="webinar-agenda-icon fas fa-info-circle"></i><span class="webinar-agenda">'.$webinar_agenda.'</span>';
                    }

                    //do registration link
                    if($registration_page_link != '#'){
                        $registration_page_link_modified = $registration_page_link.'?webinar_id='.$webinar_id;
                    } else {
                        $registration_page_link_modified = $registration_page_link;
                    }


                    $html .= '<tr>';
                        $html .= '<td>'.$webinar_topic.'</td>';
                        $html .= '<td>'.$webinar_start_combined.'</td>';
                        // $html .= '<td>'.$webinar_start_time.'</td>';
                        $html .= '<td>'.$webinar_duration.'</td>';
                        $html .= '<td><a href="'.$registration_page_link_modified.'">'.__('Register','woocommerce-to-zoom').' <i class="fas fa-arrow-circle-right"></i></a></td>';
                    $html .= '</tr>';


                }
            } else {
                $html .= '<tr><td colspan="5">'.__('There are currently no upcoming webinars.','woocommerce-to-zoom').'</td></tr>';    
            }
            

        $html .= '</tbody>';

    $html .= '</table>';

    return $html;

}
/**
* 
*
*
* Gets upcoming webinars from Zoom
*/
function woocommerce_to_zoom_get_upcoming_webinars_shortcode() {

    $transient_name = 'zoom_upcoming_webinars_shortcode';
    $transient = get_transient($transient_name);

    if ($transient != false){
        return $transient;
    } else {


        //only continue if authenticated
        if(get_option('wc_settings_zoom_refresh_token')){

            $url = woocommerce_to_zoom_get_api_base().'users/me/webinars?page_size=300';

            $response = wp_remote_get( $url, array(
                'headers' => array(
                    'Authorization' => 'Bearer '.woocommerce_to_zoom_get_access_token(),
                )
            ));

            $status = wp_remote_retrieve_response_code( $response );

            if($status == 200){
                $decodedBody = json_decode(preg_replace('/("\w+"):(\d+(\.\d+)?)/', '\\1:"\\2"', $response['body']), true);
                $webinars = $decodedBody['webinars'];
               
                //set the transient for 10 minutes
                set_transient($transient_name,$webinars, MINUTE_IN_SECONDS * 60); 

            }
        }

        return $webinars;
    }
}


?>