<?php
/**
* 
*
*
* Add new tab to WooCommerce Product Page
*/
add_filter( 'woocommerce_product_data_tabs', 'woocommerce_to_zoom_add_product_tab' );

function woocommerce_to_zoom_add_product_tab( $product_data_tabs ) {

	$product_data_tabs['zoom-webinrs'] = array(
		'label' => __( 'Webinar Selection', 'woocommerce-to-zoom' ),
		'target' => 'zoom_webinar_selection',
        'class'  => array( 'show_if_virtual'),
	);
    
	return $product_data_tabs;
}






/**
* 
*
*
* Get all active users
*/
function woocommerce_to_zoom_get_all_users() {

	$transient_name = 'zoom_all_users';
	$transient = get_transient($transient_name);
	
	if ($transient != false){
        return $transient;
    } else {

		$url = woocommerce_to_zoom_get_api_base().apply_filters( 'woocommerce_to_zoom_get_webinars_args', 'users?status=active' );

		$response = wp_remote_get( $url, array(
			'headers' => array(
				'Authorization' => 'Bearer '.woocommerce_to_zoom_get_access_token(),
			)
		));

		$status = wp_remote_retrieve_response_code( $response );

		if($status == 200){

			$decodedBody = json_decode(preg_replace('/("\w+"):(\d+(\.\d+)?)/', '\\1:"\\2"', $response['body']), true);

			$users = $decodedBody['users'];

		} else {
			$users = array();
		}

		set_transient($transient_name,$users, 60*10);

		return $users;
	}

}






/**
* 
*
*
* Gets upcoming webinars from Zoom
*/
function woocommerce_to_zoom_get_upcoming_webinars() {

    $transient_name = 'zoom_upcoming_webinars';
    $transient = get_transient($transient_name);

    if ($transient != false){
        return $transient;
    } else {

        //setup return variable
        $return_array = array(''=>'');

        //only continue if authenticated
        if(get_option('wc_settings_zoom_refresh_token')){


			// //we need to see whether we are getting meetings for just the current user or all users on the zoom account
			if(get_option('wc_settings_zoom_webinars_to_get') && get_option('wc_settings_zoom_webinars_to_get') == 'all'){

				$users = woocommerce_to_zoom_get_all_users();

				//now we need to loop through each user
				foreach($users as $user){

					$user_id = $user['id'];

					$url = esc_url(woocommerce_to_zoom_get_api_base()).'users/'.$user_id.'/webinars?'.apply_filters( 'woocommerce_to_zoom_get_webinars_all_args', 'page_size=300' );

					$response = wp_remote_get( $url, array(
						'headers' => array(
							'Authorization' => 'Bearer '.woocommerce_to_zoom_get_access_token(),
						)
					));

					$status = wp_remote_retrieve_response_code( $response );

					if($status == 200){
						$decodedBody = json_decode(preg_replace('/("\w+"):(\d+(\.\d+)?)/', '\\1:"\\2"', $response['body']), true);
						$webinars = $decodedBody['webinars'];

						foreach($webinars as $webinar){

							// $date = date_i18n(get_option( 'date_format' ),strtotime($webinar['start_time']));
							$start_time = $webinar['start_time'];
							$time_zone = $webinar['timezone'];

							$date = new DateTime($start_time, new DateTimeZone('UTC'));

							$date->setTimezone(new DateTimeZone($time_zone));
							$date = $date->format(get_option( 'date_format' ));

							//should we hide old webinars
							$hide_old_webinars = get_option('wc_settings_zoom_hide_old_webinars');

							if($hide_old_webinars == 'yes'){

								$original_date = strtotime($start_time);

								if($original_date > time()){
									$return_array[esc_attr($webinar['id'])] = esc_attr($webinar['topic']).' ('.esc_attr($date).')';
								}
								
							} else {
								$return_array[esc_attr($webinar['id'])] = esc_attr($webinar['topic']).' ('.esc_attr($date).')';
							}
								
						}
						

					} //end status

				} //end foreach

				//set the transient for 10 minutes
				set_transient($transient_name,$return_array, 60*10);

			} else {

				//just get the current users webinars
				$url = esc_url(woocommerce_to_zoom_get_api_base()).apply_filters( 'woocommerce_to_zoom_get_webinars_args', 'users/me/webinars?page_size=300' );

				$response = wp_remote_get( $url, array(
					'headers' => array(
						'Authorization' => 'Bearer '.woocommerce_to_zoom_get_access_token(),
					)
				));

				$status = wp_remote_retrieve_response_code( $response );

				if($status == 200){
					$decodedBody = json_decode(preg_replace('/("\w+"):(\d+(\.\d+)?)/', '\\1:"\\2"', $response['body']), true);
					$webinars = $decodedBody['webinars'];

					foreach($webinars as $webinar){

						// $date = date_i18n(get_option( 'date_format' ),strtotime($webinar['start_time']));
						$start_time = $webinar['start_time'];
						$time_zone = $webinar['timezone'];

						$date = new DateTime($start_time, new DateTimeZone('UTC'));

						$date->setTimezone(new DateTimeZone($time_zone));
						$date = $date->format(get_option( 'date_format' ));

						//should we hide old webinars
						$hide_old_webinars = get_option('wc_settings_zoom_hide_old_webinars');

						if($hide_old_webinars == 'yes'){

							$original_date = strtotime($start_time);

							if($original_date > time()){
								$return_array[esc_attr($webinar['id'])] = esc_attr($webinar['topic']).' ('.esc_attr($date).')';
							}
							
						} else {
							$return_array[esc_attr($webinar['id'])] = esc_attr($webinar['topic']).' ('.esc_attr($date).')';
						}
							
					}
					
					//set the transient for 10 minutes
					set_transient($transient_name,$return_array, 60*10); 

				}
			}



		}
		


        return $return_array;
    }
}

/**
* 
*
*
* Function to render a list item
*/
function woocommerce_to_zoom_list_item_render($selected_option){

	//start output
	$html = '';


	$html .= '<li>';

		//need to do a move icon
		$html .= '<span class="dashicons dashicons-move"></span>';

		//need to do a select
		$html .= '<select>';
			//need to do options here...

			//do initial blank option
			$html .= '<option value=""></option>';	

			$webinars = woocommerce_to_zoom_get_upcoming_webinars();

			// $webinars = array(
			// 	'1' => 'Hey',
			// 	'2' => 'Man',
			// 	'3' => 'How',
			// 	'4' => 'Is',
			// 	'5' => 'It',
			// 	'6' => 'Going',
			// );

			foreach($webinars as $webinar_id => $webinar_label){
				if($webinar_id == $selected_option){
					$html .= '<option value="'.$webinar_id.'" selected="selected">'.$webinar_label.'</option>';	
				} else {
					$html .= '<option value="'.$webinar_id.'">'.$webinar_label.'</option>';	
				}
			}


			//need to parse woocommerce_to_zoom_get_upcoming_webinars()
		$html .= '</select>';

		//need to do an add
		$html .= '<span class="dashicons dashicons-plus"></span>';

		//need to do a minus
		$html .= '<span class="dashicons dashicons-minus"></span>';
		

	$html .= '</li>';

	return $html;

}


/**
* 
*
*
* Add new tab to WooCommerce Product Page
*/
add_action( 'woocommerce_product_data_panels', 'woocommerce_to_zoom_tab_content');
function woocommerce_to_zoom_tab_content() {

	global $woocommerce, $post;

	$post_id = $post->ID;

	$key = 'zoom_webinar_selection';

	if(strlen(get_post_meta($post_id,$key , true)) > 0){
		$selected_webinars = get_post_meta($post_id,$key , true);
	}

	?>
	<!-- id below must match target registered in above add_my_custom_product_data_tab function -->
	<div id="zoom_webinar_selection" class="panel woocommerce_options_panel">
		<?php
    

		//do label
		echo '<label class="multiple-selection-list-label">'.__( 'Please select a webinar', 'woocommerce-to-zoom' ).'</label>';

		//do list items
		echo '<ul data="'.$post_id.'" class="multiple-selection-list">';

			//need to get an option

			if(isset($selected_webinars)){

				$exploded_webinars = explode(',',$selected_webinars);

				foreach($exploded_webinars as $webinar){
					echo woocommerce_to_zoom_list_item_render($webinar);
				}

			} else {
				echo woocommerce_to_zoom_list_item_render('');
			}
			

		echo '</ul>';
		
		//hide the following option from showing
		echo '<style>
		.form-field.zoom_webinar_selection_field {
			display: none !important;
		}
		</style>';

		woocommerce_wp_text_input(array( 
			'id'            => $key, 
			'wrapper_class' => 'show_if_virtual', 
			'label'         => __( 'Please select a webinar', 'woocommerce-to-zoom' ),
            'description'   => __( '', 'woocommerce-to-zoom' ), 
			// 'options' => woocommerce_to_zoom_get_upcoming_webinars()
		));



    
		?>
	</div>



	<?php
}



/**
* 
*
*
* Add new tab to WooCommerce Product Page - Variations
*/
add_action( 'woocommerce_product_after_variable_attributes', 'woocommerce_to_zoom_tab_content_variations' ,10,3);
function woocommerce_to_zoom_tab_content_variations($loop, $variation_data, $variation) {

	?>
	<!-- id below must match target registered in above add_my_custom_product_data_tab function -->
	<div id="zoom_webinar_selection" class="panel woocommerce_options_panel">
		<?php
    


	
		// $key = 'zoom_webinar_selection';

		// if(strlen(get_post_meta($variation->ID,$key , true)) > 0){
		// 	$selected_webinars = get_post_meta($variation->ID,$key , true);
		// }


		// //do label
		// echo '<label class="multiple-selection-list-label">'.__( 'Please select a webinar', 'woocommerce-to-zoom' ).'</label>';

		// //do list items
		// echo '<ul data="'.$variation->ID.'" class="multiple-selection-list">';

		// 	//need to get an option

		// 	if(isset($selected_webinars)){

		// 		$exploded_webinars = explode(',',$selected_webinars);

		// 		foreach($exploded_webinars as $webinar){
		// 			echo woocommerce_to_zoom_list_item_render($webinar);
		// 		}

		// 	} else {
		// 		echo woocommerce_to_zoom_list_item_render('');
		// 	}
			

		// echo '</ul>';
		
		// //hide the following option from showing
		// echo '<style>

		// .hide_webinar_selection_input
		// {
		// 	display: none !important;
		// }
		// </style>';

		// woocommerce_wp_text_input(array( 
		// 	'id'            => 'zoom_webinar_selection['.$variation->ID.']', 
		// 	'wrapper_class' => 'show_if_variation_virtual hide_webinar_selection_input', 
		// 	'label'         => __( 'Please select a webinar', 'woocommerce-to-zoom' ),
        //     'description'   => __( '', 'woocommerce-to-zoom' ), 
		// 	// 'options' => woocommerce_to_zoom_get_upcoming_webinars()
		// 	'value'       => get_post_meta( $variation->ID, 'zoom_webinar_selection', true ),
		// ));
	



		woocommerce_wp_select(array( 
			'id'            => 'zoom_webinar_selection['.$variation->ID.']', 
			'wrapper_class' => 'show_if_variation_virtual', 
			'label'         => __( 'Please select a webinar', 'woocommerce-to-zoom' ),
			'description'   => __( '', 'woocommerce-to-zoom' ), 
			'value'       => get_post_meta( $variation->ID, 'zoom_webinar_selection', true ),
			'options' => woocommerce_to_zoom_get_upcoming_webinars()
		));


		
    
		?>
	</div>



	<?php
}



/**
* 
*
*
* Save the data from the tab
*/
add_action('woocommerce_process_product_meta', 'woocommerce_to_zoom_save_tab_settings');
function woocommerce_to_zoom_save_tab_settings( $post_id ) {

    if ( isset( $_POST['zoom_webinar_selection'] ) ) {
			update_post_meta( $post_id, 'zoom_webinar_selection', wc_clean( $_POST['zoom_webinar_selection'] ) );
	}

}


/**
* 
*
*
* Save the data from the tab - Variations
*/
add_action('woocommerce_save_product_variation', 'woocommerce_to_zoom_save_tab_settings_variations',10,2);
function woocommerce_to_zoom_save_tab_settings_variations( $post_id ) {

    $select = $_POST['zoom_webinar_selection'][ $post_id ];
	if( ! empty( $select ) ) {
		update_post_meta( $post_id, 'zoom_webinar_selection', esc_attr( $select ) );
	}

}



?>