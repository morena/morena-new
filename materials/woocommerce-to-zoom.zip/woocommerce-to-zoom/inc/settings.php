<?php

/**
* 
*
*
* Add our new settings tab and settings
*/
class WC_Settings_WooCommerce_To_Zoom {
    /**
     * Bootstraps the class and hooks required actions & filters.
     *
     */
    public static function init() {
        add_filter( 'woocommerce_settings_tabs_array', __CLASS__ . '::add_settings_tab', 50 );
        add_action( 'woocommerce_settings_tabs_zoom', __CLASS__ . '::settings_tab' );
        add_action( 'woocommerce_update_options_zoom', __CLASS__ . '::update_settings' );
    }
    /**
     * Add a new settings tab to the WooCommerce settings tabs array.
     *
     * @param array $settings_tabs Array of WooCommerce setting tabs & their labels, excluding the Subscription tab.
     * @return array $settings_tabs Array of WooCommerce setting tabs & their labels, including the Subscription tab.
     */
    public static function add_settings_tab( $settings_tabs ) {
        $settings_tabs['zoom'] = __( 'Zoom', 'woocommerce-to-zoom' );
        return $settings_tabs;
    }

    public static function output_right_sidebar_content(  ) {
        
        //frequently asked questions
        $faq = array(
            __('How do I actually use this plugin?','woocommerce-to-zoom') => __('Please follow the following steps:<br><ol>
                <li>Enter the order/purchase email at the top of this settings page to receive automatic updates and support.</li>  
                <li>Click the big blue connect button on this page which will connect your website to your Zoom account. It\'s working when you see the status next to the button saying "Connected".</li>
                <li>Create a WooCommerce product or go to an existing WooCommerce product and ensure you set the product as virtual and add any other parameters you want for the product like price etc. and then you will a webinar selection tab. This is where you can select your webinar. Once you are done click save settings.</li>
                <li>That\'s it. Once someone purchases your product they will be automatically registered for the webinar.</li>
            </ol>
            
            ','woocommerce-to-zoom'),


            __('When I click the "Connect with Zoom" button I get an error?','woocommerce-to-zoom') => __('Make sure on this settings page you don\'t have "Sandbox Mode" activated. Please uncheck this, save the settings, refresh the page, and then click the connect button again. Otherwise, make sure you have a Zoom account to connect to.
            
            ','woocommerce-to-zoom'),



            __('Users are not being registered for the Zoom webinar?','woocommerce-to-zoom') => __('There are a couple of reasons this could occur:
                <br></br>
                <ol>
                    <li><strong>Orders aren\'t being marked as complete</strong> - Only completed orders are synced to Zoom. If you\'re using a payment method like PayPal or Stripe in test mode often they won\'t mark the orders as complete, however in live mode they do mark them as complete automatically. So for testing purposes just mark the order as complete from your <a href="'.esc_url(get_admin_url()).'edit.php?post_type=shop_order">orders</a> page. If you are accepting cash or cheque payments or some kind of offline payment and you want to mark orders automatically as complete you can use this code snippet <a target="_blank" href="https://docs.woocommerce.com/document/automatically-complete-orders/">here</a> or you can use this premium <a target="_blank" href="https://woocommerce.com/products/woocommerce-order-status-control/">plugin</a>.</li>
                    <li><strong>You are using an email on your Zoom account during your testing</strong> - If you are testing out the plugin you might have entered in your Zoom account email or the email of a user on your Zoom account during the checkout process. You can not register for your own webinar. So for testing purposes try a different email address and it should work ok.</li>
                    <li><strong>Ensure registration is required</strong> - In Zoom, on the webinar edit page, make sure for "Registration" you have the "Required" checkbox checked.</li>
                    <li><strong>You have only authenticated users can join</strong> - In Zoom, on the webinar edit page, make sure for "Only authenticated users can join" is unchecked.</li>
                </ol>','woocommerce-to-zoom'),

            __('I just added a new webinar in Zoom but can\'t see it on the product page?','woocommerce-to-zoom') => __('Webinars are cached and get refreshed every hour so there may be some delay between updates in Zoom vs what is shown on your site. You can clear the cache though by clicking the link just above the save settings button on this settings page.','woocommerce-to-zoom'),

            __('I can\'t see the Zoom webinar selection tab on the product page?','woocommerce-to-zoom') => __('Please ensure you set the product as virtual - only once a product is set as virtual will the tab appear. Please check out this image <a target="_blank" href="https://northernbeacheswebsites.com.au/root-nbw/wp-content/uploads/2019/12/Zoom-Webinar-Product-Edit-Page-2048x586.jpg">here</a> showing this. Also try re-connecting again by clicking the "Connect with Zoom" button on this page.','woocommerce-to-zoom'),

            __('How do users receive notification of successful registration?','woocommerce-to-zoom') => __('This is all handled by Zoom and they provide a range of options to customise the emails. Please click <a target="_blank" href="https://support.zoom.us/hc/en-us/articles/203686335-Webinar-Email-Settings">here</a> to learn more about this. There is also a setting on this page called "Enable Completed Order Email Registration Links" which adds to the WooCommerce completed order email (so sent to the purchaser) which contains a list of registrants and their respective registration links.','woocommerce-to-zoom'),

            __('Can I show webinars in a table and have registration forms on my site i.e. offer free webinars?','woocommerce-to-zoom') => __('Yes! Follow these steps:
                
                <ol>
                    <li>Create a page and put the following shortcode on it: [zoom_registration_table] (this is what shows the webinars in a table)</li>
                    <li>Now create another page and put the following shortcode on it: [zoom_registration_form] (this is where the registration forms will be)</li>
                    <li>On this plugin setting page select the page you just added the shortcode to in step 2 in the setting called "Registration Page Selection"</li>
                    <li>Create a third thank you page which is where people will be redirected after completing the form and select this page in the settings on this page "Thank You Page Selection"</li>
                    <li>Now just direct visitors to the page you created in step 1!</li>
                </ol>
                
                ','woocommerce-to-zoom'),


            __('I am having some kind of other issue?','woocommerce-to-zoom') => __('First make sure you are using the latest version of this plugin; you can check for updates from your main <a href="'.esc_url(get_admin_url()).'plugins.php">plugins page</a>. If this does not solve your issue please contact me <a target="_blank" href="https://northernbeacheswebsites.com.au/support/">here</a>. Please note, I am located in Sydney, Australia so there may be some time difference in my reply however you will most certainly receive a response within 24 hours on weekdays.','woocommerce-to-zoom'),
        );


        //start output
        $html = '';
        $html .= '<div class="faq-container-webinars">';
            //do heading
            $html .= '<ul class="zoom-faq">';
            $html .= '<h2>'.__('Frequently Asked Questions','woocommerce-to-zoom').'</h2>';

                foreach($faq as $question => $answer){
                    $html .= '<li>';
                        $html .= '<h2 class="question"><span class="dashicons dashicons-plus"></span> '.esc_html($question).'</h2>';
                        $html .= '<span class="answer">'.esc_html($answer).'</span>';
                    $html .= '</li>';
                }
                

            $html .= '</ul>';
        $html .= '</div>';

        return $html;
    }



    public static function get_wordpress_pages() {

        $options = array();

        $pages = get_pages();

        foreach($pages as $page){
            $options[esc_html($page->ID)] = esc_html($page->post_title);
        }

        return $options;
    }

    
    
    /**
     * Uses the WooCommerce admin fields API to output settings via the @see woocommerce_admin_fields() function.
     *
     * @uses woocommerce_admin_fields()
     * @uses self::get_settings()
     */
    public static function settings_tab() {
        woocommerce_admin_fields( self::get_settings() );
        echo self::output_right_sidebar_content();
    }
    /**
     * Uses the WooCommerce options API to save settings via the @see woocommerce_update_options() function.
     *
     * @uses woocommerce_update_options()
     * @uses self::get_settings()
     */
    public static function update_settings() {
        woocommerce_update_options( self::get_settings() );
    }
    /**
     * Get all the settings for this plugin for @see woocommerce_admin_fields() function.
     *
     * @return array Array of settings for @see woocommerce_admin_fields() function.
     */
    public static function get_settings() {
        

        $settings = array(


            //updates
            array(
                'name'     => __( 'Licence Settings', 'woocommerce-to-zoom' ),
                'type'     => 'title',
            ),
            array(
                'name' => __( 'Order Email', 'woocommerce-to-zoom' ),
                'type' => 'text',
                'desc_tip' => __( 'The email used to purchase the plugin.', 'woocommerce-to-zoom' ),
                'id'   => 'wc_settings_zoom_order_email'
            ),
            array(
                'name' => __( 'Order ID', 'woocommerce-to-zoom' ),
                'type' => 'text',
                'desc_tip' => __( 'This order id number was sent to your email address upon purchase of the plugin. You should enter this like: 12345, not #12345 or any other variant.', 'woocommerce-to-zoom' ),
                'id'   => 'wc_settings_zoom_order_id'
            ),
            array(
                'name' => __( 'Sandbox Mode', 'woocommerce-to-zoom' ),
                'type' => 'checkbox',
                'desc_tip' => __( 'It is advised to keep this unchecked unless directed otherwise.', 'woocommerce-to-zoom' ),
                'id'   => 'wc_settings_zoom_sandbox_mode'
            ),


            //section end
            array( 'type' => 'sectionend' ),

            array(
                'name'     => __( 'Completed Order Notification', 'woocommerce-to-zoom' ),
                'type'     => 'title',
            ),
            array(
                'name' => __( 'Enable Completed Order Email Registration Links', 'woocommerce-to-zoom' ),
                'type' => 'checkbox',
                'desc_tip' => __( 'When checked, we will add a list on your WooCommerce Completed Order email which will contain a list of webinar registrants and their respective registration links. Please ensure you have enabled your completed order email <a href="'.esc_url(get_admin_url()).'admin.php?page=wc-settings&tab=email">here</a>.', 'woocommerce-to-zoom' ),
                'id'   => 'wc_settings_zoom_enable_completed_order_email'
            ),

            //section end
            array( 'type' => 'sectionend' ),

            array(
                'name'     => __( 'Past Webinar Products', 'woocommerce-to-zoom' ),
                'type'     => 'title',
            ),
            array(
                'name' => __( 'What do you want to do with old webinar products in WooCommerce?', 'woocommerce-to-zoom' ),
                'type' => 'select',
                'id'   => 'wc_settings_zoom_old_webinar_products',
                'options'  => array('nothing'=>__('Do nothing','woocommerce-to-zoom'),'draft'=>__('Make them a draft','woocommerce-to-zoom'),'delete'=>__('Delete them','woocommerce-to-zoom'))
            ),


            //section end
            array( 'type' => 'sectionend' ),

            array(
                'name'     => __( 'Free Webinar Table & Registration Forms', 'woocommerce-to-zoom' ),
                'type'     => 'title',
            ),
            array(
                'name' => __( 'Registration Page Selection', 'woocommerce-to-zoom' ),
                'type' => 'select',
                'desc_tip' => __( 'Please first put the shortcode on any page of your choosing: [zoom_registration_table] then create a registration page and put the following shortcode on it: [zoom_registration_form] and then in this dropdown select the page which you put this registration form shortcode.', 'woocommerce-to-zoom' ),
                'id'   => 'wc_settings_zoom_registration_page',
                'options'  => self::get_wordpress_pages()
            ),
            array(
                'name' => __( 'Thank You Page Selection', 'woocommerce-to-zoom' ),
                'type' => 'select',
                'desc_tip' => __( 'This is where you would like the registrant to go after the form has been successfully completed.', 'woocommerce-to-zoom' ),
                'id'   => 'wc_settings_zoom_thank_you_page',
                'options'  => self::get_wordpress_pages()
            ),


             //section end
             array( 'type' => 'sectionend' ),

             array(
                 'name'     => __( 'Checkout Page Options', 'woocommerce-to-zoom' ),
                 'type'     => 'title',
             ),

             array(
                'name' => __( 'Hide Checkout Form - read help before enabling', 'woocommerce-to-zoom' ),
                'type' => 'checkbox',
                'desc_tip' => __( 'If this option is enabled we will hide the registration form on the checkout page. Caution, this should only be enabled if you are not adding custom/additional fields for the registration form in Zoom otherwise you will get registration errors. If you don\'t understand what this is all about, just leave this unchecked.', 'woocommerce-to-zoom' ),
                'id'   => 'wc_settings_zoom_hide_checkout_form'
            ),


            //section end
            array( 'type' => 'sectionend' ),

            array(
                'name'     => __( 'Product Settings Options', 'woocommerce-to-zoom' ),
                'type'     => 'title',
            ),

            array(
               'name' => __( 'Don\'t show previous webinars in webinar selection dropdown', 'woocommerce-to-zoom' ),
               'type' => 'checkbox',
               'desc_tip' => __( 'If this option is enabled we will hide previous webinars from the dropdown on your product edit page.', 'woocommerce-to-zoom' ),
               'id'   => 'wc_settings_zoom_hide_old_webinars'
           ),

           array(
                'name' => __( 'Webinars to get', 'woocommerce-to-zoom' ),
                'type' => 'select',
                'id'   => 'wc_settings_zoom_webinars_to_get',
                'options'  => array('mine'=>__('Only get my webinrs','woocommerce-to-zoom'),'all'=>__('Get webinars from all users on my Zoom account','woocommerce-to-zoom'))
            ),


            //section end
            array( 'type' => 'sectionend' ),

            //connection
            array(
                'name'     => __( 'Connect with Zoom Webinars', 'woocommerce-to-zoom' ),
                'type'     => 'title',
                'desc'  => woocommerce_to_zoom_connect_button(),
            ),
            //section end
            array( 'type' => 'sectionend' ),

 

           

        );
      
        return apply_filters( 'wc_settings_zoom', $settings );
    }
}
WC_Settings_WooCommerce_To_Zoom::init();
/**
* 
*
*
* Output appropriate code for connect button and disconnect link
*/
function woocommerce_to_zoom_connect_button(){

        //output connect button

        $connectUrl = 'https://zoom.us/oauth/authorize?response_type=code&';
        $connectUrl .= 'client_id='.esc_attr(woocommerce_to_zoom_get_client_id());
        $connectUrl .= '&';
        $connectUrl .= 'redirect_uri='.esc_attr(woocommerce_to_zoom_get_redirect_uri());
        $connectUrl .= '&';
        $connectUrl .= 'state='.esc_attr(get_admin_url()).'zoomwebinar';

        $return_data = '<a target="_self" href="'.esc_url($connectUrl).'" id="zoom-connect-button" class="button-secondary"><span class="video-icon dashicons dashicons-video-alt2"></span> '.__('Connect with Zoom','woocommerce-to-zoom').'</a>';

        //lets also show a connected status
        if(get_option('wc_settings_zoom_refresh_token') && strlen(get_option('wc_settings_zoom_refresh_token'))>0){
            $return_data .= '<span class="connection-container"><span class="status-text">'.__('Status:','woocommerce-to-zoom').'</span> <span class="connected-text">'.__('Connected','woocommerce-to-zoom').'</span> <a class="disconnect-from-zoom" href="#">'.__('Disconnect Now','woocommerce-to-zoom').'</a></span>';   
        } else {
            $return_data .= '<span class="connection-container"><span class="status-text">'.__('Status:','woocommerce-to-zoom').'</span> <span class="disconnected-text">'.__('Disconnected','woocommerce-to-zoom').'</span></span>';   
        }


        //lets also output the ability to clear transients
        $return_data .= '<div class="transient-settings"><a id="clear-zoom-transients" href="#">'.__('Clear Cache','woocommerce-to-zoom').'</a> <em>'.__('(If you update your registration form fields in Zoom, the form fields will be cached for an hour so they may not show straight away, so use this button to clear the cache)','woocommerce-to-zoom').'</em></div>';   

        return $return_data;

  
}
?>