<?php



/**
* 
*
*
* Gets registration fields for a webinar
*/
function woocommerce_to_zoom_get_webinar_registration_fields($webinar_id) {

    $webinar_id = woocommerce_to_zoom_sanitize_webinar_id($webinar_id);

    $transient_name = 'zoom_registration_fields_'.$webinar_id;
    $transient = get_transient($transient_name);

    if ($transient != false){
        return $transient;
    } else {

        $url = woocommerce_to_zoom_get_api_base().'webinars/'.$webinar_id.'/registrants/questions';

        $response = wp_remote_get( $url, array(
            'headers' => array(
                'Authorization' => 'Bearer '.woocommerce_to_zoom_get_access_token(),
            )
        ));

        $status = wp_remote_retrieve_response_code( $response );

        if($status == 200){

            $decodedBody = json_decode(preg_replace('/("\w+"):(\d+(\.\d+)?)/', '\\1:"\\2"', $response['body']), true);
            
            //set the transient for 1 hour
            set_transient($transient_name,$decodedBody, 60*60); 

            return $decodedBody;

        }

    }
}



/**
* 
*
*
* Adds custom fields to the woocommerce checkout area
*/
add_action( 'woocommerce_after_order_notes', 'woocommerce_to_zoom_checkout_fields' );

function woocommerce_to_zoom_checkout_fields( $checkout ) {

    global $woocommerce;
    $cart = $woocommerce->cart->get_cart();
    $cart_items_ids = array();
    
    //do pre-query to find out whether webinars exist for the purpose of the button
    $webinars_exist = false;
    foreach ( $cart as $item_key => $item_value ) {
        $cart_product_id = $item_value[ 'data' ] -> get_id();
        $webinar_id = get_post_meta( $cart_product_id, 'zoom_webinar_selection', true );

        if(strlen($webinar_id)>0){
            $webinars_exist = true;
        }
    }

    //add class to specific areas to hide it
    $hide_checkout_form = get_option('wc_settings_zoom_hide_checkout_form');

    if($hide_checkout_form == 'yes'){
        $additional_class = 'zoom-hide-checkout-form';
    } else {
        $additional_class = '';       
    }


    //do button if webinars exist
    if($webinars_exist){
        echo '<button class="woocommerce-to-zoom-copy-from-billing '.$additional_class.'">'.__('Copy from billing details','woocommerce-to-zoom').'</button>';
    }

    //loop through each item in the cart    
    foreach ( $cart as $item_key => $item_value ) {

        //get variables for the cart item
        $cart_product_id = $item_value[ 'data' ] -> get_id();
        $cart_product_title = $item_value[ 'data' ] -> get_title();  
        $cart_product_slug = $item_value[ 'data' ]->get_slug();   
        $cart_product_qty = $item_value['quantity'];    

        $webinar_id = get_post_meta( $cart_product_id, 'zoom_webinar_selection', true );  

        // $webinar_id = woocommerce_to_zoom_sanitize_webinar_id($webinar_id);
        
        if(strlen($webinar_id)>0){

            // var_dump($webinar_id);

            $multiple_webinars = explode(',',$webinar_id);

            foreach($multiple_webinars as $webinar_id){

                echo '<div class="zoom-webinar-section" style="margin-top: 30px;">';

                    do_action( 'woocommerce_to_zoom_before_product_title' );

                    //do heading
                    echo '<h3 class="'.$additional_class.'">'.$cart_product_title.'</h3>';

                    do_action( 'woocommerce_to_zoom_after_product_title' );

                    //lets get the registration fields for the webinar
                    $registration_fields = woocommerce_to_zoom_get_webinar_registration_fields($webinar_id);



                    //lets now loop through each registrant by using the QTY as a guide
                    for ($i = 1 ; $i <= $cart_product_qty; $i++){

                        //create wrapper for each registrant qty
                        echo '<div class="zoom-webinar-registrant-container '.$additional_class.'-'.$i.'">';
                            echo '<strong class="zoom-webinar-registrant-section">'.__('Registrant','woocommerce-to-zoom').' '.$i.'</strong>';

                            //first we need to do the required fields which is the first name and email
                            //DO FIRST NAME
                            $field_identifier = $webinar_id.'-'.$i.'-first_name';

                            $field_class = array('form-row-wide '.$field_identifier.' '.$i.'-first_name first_name');   

                            $field_options = array();

                            woocommerce_form_field( $field_identifier, array(
                                'type'          => 'text',
                                'required'      => true,   
                                'class'         => $field_class,
                                'label'         => __('First Name','woocommerce-to-zoom'),
                                'maxlength'     => false,   
                                'placeholder'   => __('','woocommerce-to-zoom'),
                                'options'       => $field_options,    
                            ), $checkout->get_value( $field_identifier )); 

                            //DO LAST NAME
                            $field_identifier = $webinar_id.'-'.$i.'-last_name';

                            $field_class = array('form-row-wide '.$field_identifier.' '.$i.'-last_name last_name');  

                            $field_options = array();

                            woocommerce_form_field( $field_identifier, array(
                                'type'          => 'text',
                                'required'      => true,   
                                'class'         => $field_class,
                                'label'         => __('Last Name','woocommerce-to-zoom'),
                                'maxlength'     => false,   
                                'placeholder'   => __('','woocommerce-to-zoom'),
                                'options'       => $field_options,    
                            ), $checkout->get_value( $field_identifier )); 

                            //DO EMAIL
                            $field_identifier = $webinar_id.'-'.$i.'-email';

                            $field_class = array('form-row-wide '.$field_identifier.' '.$i.'-email email');    

                            $field_options = array();

                            woocommerce_form_field( $field_identifier, array(
                                'type'          => 'email',
                                'required'      => true,   
                                'class'         => $field_class,
                                'label'         => __('Email','woocommerce-to-zoom'),
                                'maxlength'     => false,   
                                'placeholder'   => __('','woocommerce-to-zoom'),
                                'options'       => $field_options,    
                            ), $checkout->get_value( $field_identifier )); 


                            //now we need to do our API registration fields

                            //lets do our standard fields first
                            if(is_array($registration_fields) && count($registration_fields['questions'])>0){

                                $field_type_helper = array(
                                    // 'last_name' => 'text',
                                    'address' => 'text',
                                    'city' => 'text',
                                    'country' => 'country',
                                    'zip' => 'text',
                                    'state' => 'state',
                                    'phone' => 'tel',
                                    'industry' => 'text',
                                    'org' => 'text',
                                    'job_title' => 'text',
                                    'purchasing_time_frame' => 'text',
                                    'role_in_purchase_process' => 'text',
                                    'no_of_employees' => 'number',
                                    'comments' => 'text',
                                );

                                foreach($registration_fields['questions'] as $question){

                                    $field_name = $question['field_name'];
                                    //dont do last name field because we have already done it
                                    if($field_name != 'last_name'){
                                        $required = $question['required'];

                                        $field_identifier = $webinar_id.'-'.$i.'-'.$field_name;
                                        $field_class = array('form-row-wide '.$field_identifier.' '.$i.'-'.$field_name.' '.$field_name);   

                                        $label = str_replace('_',' ',$field_name);
                                        $label = ucwords($label);


                                        woocommerce_form_field( $field_identifier, array(
                                            'type'          => $field_type_helper[$field_name],
                                            'required'      => $required,   
                                            'class'         => $field_class,
                                            'label'         => __($label,'woocommerce-to-zoom'),   
                                        ), $checkout->get_value( $field_identifier )); 
                                    }
                                }
                            }

                            //now lets do our custom questions
                            if(is_array($registration_fields) && count($registration_fields['custom_questions'])>0){

                                foreach($registration_fields['custom_questions'] as $question){

                                    $field_title = $question['title'];
                                    $field_title_translated = base64_encode($field_title);
                                    $required = $question['required'];
                                    $type = $question['type'];
                                    $answers = $question['answers'];

                                    //we want to replace the keys with the values
                                    $new_answers = array();

                                    foreach($answers as $key => $value){
                                        $new_answers[$value] = $value;
                                    }

                                    $field_identifier = $webinar_id.'-'.$i.'-'.$field_title_translated;
                                    $field_class = array('form-row-wide '.$field_identifier);  

                                    // $label = str_replace('_',' ',$field_name);
                                    // $label = ucwords($label);

                                    //translate the field type
                                    if($type == 'short'){
                                        $field_type = 'text';
                                    }

                                    if($type == 'multiple'){
                                        $field_type = 'radio';
                                    }

                                    if($type == 'single_radio'){
                                        $field_type = 'radio';
                                    }

                                    if($type == 'single_dropdown'){
                                        $field_type = 'select';
                                    }

                                    $select_types = array('multiple','single_radio','single_dropdown');

                                    $temp_array = array(
                                        'type'          => $field_type,
                                        'required'      => $required,   
                                        'class'         => $field_class,
                                        'label'         => __($field_title,'woocommerce-to-zoom'),   
                                    );

                                    if(in_array($type,$select_types)){
                                        $temp_array['options'] = $new_answers;  
                                    }


                                    woocommerce_form_field( $field_identifier,$temp_array , $checkout->get_value( $field_identifier )); 



                                }
                            }
                        echo '</div>';
                    } //end for each quantity
                
                echo '</div>';

            } //end foreach

        }
        
    }
}


/**
* 
*
*
* Save the data
*/
add_action( 'woocommerce_checkout_update_order_meta', 'woocommerce_to_zoom_save_checkout_fields' );

function woocommerce_to_zoom_save_checkout_fields( $order_id ) {
    

    global $woocommerce;
    $cart = $woocommerce->cart->get_cart();
    $cart_items_ids = array();
    
    //start the main loop
    foreach ( $cart as $item_key => $item_value ) {
    
        $cart_product_id = $item_value[ 'data' ]->get_id(); 
        $cart_product_qty = $item_value['quantity'];    

        $webinar_id = get_post_meta( $cart_product_id, 'zoom_webinar_selection', true );  

        // $webinar_id = woocommerce_to_zoom_sanitize_webinar_id($webinar_id);

        if(strlen($webinar_id)>0){

            $multiple_webinars = explode(',',$webinar_id);

            foreach($multiple_webinars as $webinar_id){

                $registration_fields = woocommerce_to_zoom_get_webinar_registration_fields($webinar_id);

                for ($i = 1 ; $i <= $cart_product_qty; $i++){

                    $order_meta = array();

                    //do compulsory fields
                    //first name
                    $field_identifier = $webinar_id.'-'.$i.'-first_name';

                    if ( !empty($_POST[$field_identifier]) ) {
                        $order_meta['first_name'] = sanitize_text_field($_POST[$field_identifier]); 
                    }

                    //last name
                    $field_identifier = $webinar_id.'-'.$i.'-last_name';

                    if ( !empty($_POST[$field_identifier]) ) {
                        $order_meta['last_name'] = sanitize_text_field($_POST[$field_identifier]); 
                    }

                    //email
                    $field_identifier = $webinar_id.'-'.$i.'-email';

                    if ( !empty($_POST[$field_identifier]) ) {
                        $order_meta['email'] = sanitize_text_field($_POST[$field_identifier]); 
                    }

                    //do standard fields
                    if(is_array($registration_fields) && count($registration_fields['questions'])>0){
                        foreach($registration_fields['questions'] as $question){
                            $field_name = $question['field_name'];
                            $field_identifier = $webinar_id.'-'.$i.'-'.$field_name;

                            if ( !empty($_POST[$field_identifier]) ) {
                                $order_meta[$field_name] = sanitize_text_field($_POST[$field_identifier]); 
                            }
                        }
                    }

                    //do custom fields
                    if(is_array($registration_fields) && count($registration_fields['custom_questions'])>0){

                        $temp_array = array();

                        foreach($registration_fields['custom_questions'] as $question){

                            $field_title = $question['title'];
                            $field_title_translated = base64_encode($field_title);

                            $field_identifier = $webinar_id.'-'.$i.'-'.$field_title_translated;

                            if ( !empty($_POST[$field_identifier]) ) {

                                array_push($temp_array,array(
                                    'title' => $field_title,
                                    'value' => sanitize_text_field($_POST[$field_identifier]),
                                ));

                            }

                        }
                        //now add to main array
                        $order_meta['custom_questions'] = $temp_array; 

                    }

                    update_post_meta( $order_id, 'zoom_webinar-'.$webinar_id.'-'.$i, $order_meta );


                }
            } //end foreach webinar

        }

    }
    
}



/**
* 
*
*
* Make required fields actually required
*/
add_action( 'woocommerce_checkout_process', 'woocommerce_to_zoom_require_checkout_fields' );
function woocommerce_to_zoom_require_checkout_fields() {
    
    global $woocommerce;
    $cart = $woocommerce->cart->get_cart();
    $cart_items_ids = array();
    
    //start the main loop
    foreach ( $cart as $item_key => $item_value ) {
    
        $cart_product_id = $item_value[ 'data' ]->get_id(); 
        $cart_product_qty = $item_value['quantity'];    

        $webinar_id = get_post_meta( $cart_product_id, 'zoom_webinar_selection', true ); 
        
        // $webinar_id = woocommerce_to_zoom_sanitize_webinar_id($webinar_id);
        
        if(strlen($webinar_id)>0){

            $multiple_webinars = explode(',',$webinar_id);

            foreach($multiple_webinars as $webinar_id){

                $registration_fields = woocommerce_to_zoom_get_webinar_registration_fields($webinar_id);

                for ($i = 1 ; $i <= $cart_product_qty; $i++){

                    //do compulsory fields
                    //first name
                    $field_identifier = $webinar_id.'-'.$i.'-first_name';

                    if ( ! $_POST[$field_identifier]) {
                        wc_add_notice( __( 'This webinar registration field is required.','woocommerce-to-zoom' ), 'error' );
                    }

                    //last name
                    $field_identifier = $webinar_id.'-'.$i.'-last_name';

                    if ( ! $_POST[$field_identifier]) {
                        wc_add_notice( __( 'This webinar registration field is required.','woocommerce-to-zoom' ), 'error' );
                    }

                    //email
                    $field_identifier = $webinar_id.'-'.$i.'-email';

                    if ( ! $_POST[$field_identifier]) {
                        wc_add_notice( __( 'This webinar registration field is required.','woocommerce-to-zoom' ), 'error' );
                    }

                    //also validate email
                    if(!filter_var($_POST[$field_identifier], FILTER_VALIDATE_EMAIL)){
                        wc_add_notice( __( 'Please enter a valid email address.','woocommerce-to-zoom' ), 'error' );
                    }


                    //do standard fields
                    if(is_array($registration_fields) && count($registration_fields['questions'])>0){
                        foreach($registration_fields['questions'] as $question){
                            $field_name = $question['field_name'];
                            $required = $question['required'];
                            $field_identifier = $webinar_id.'-'.$i.'-'.$field_name;

                            if ( !$_POST[$field_identifier] && $required) {
                                wc_add_notice( __( 'This webinar registration field is required.','woocommerce-to-zoom' ), 'error' ); 
                            }
                        }
                    }

                    //do custom fields
                    if(is_array($registration_fields) && count($registration_fields['custom_questions'])>0){

                        foreach($registration_fields['custom_questions'] as $question){

                            $field_title = $question['title'];
                            $field_title_translated = base64_encode($field_title);
                            $required = $question['required'];
                            $field_identifier = $webinar_id.'-'.$i.'-'.$field_title_translated;

                            if ( !$_POST[$field_identifier] &&  $required) {
                                wc_add_notice( __( 'This webinar registration field is required.','woocommerce-to-zoom' ), 'error' );
                            }

                        }
                    }

                }
            } //end foreach webinar

        }

    }

}
  


?>