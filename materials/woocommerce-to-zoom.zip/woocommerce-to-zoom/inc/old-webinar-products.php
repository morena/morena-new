<?php

/**
* 
*
*
* Automatically delete or make draft old webinar products
*/
add_action('admin_init','woocommerce_to_zoom_old_webinar_products');

function woocommerce_to_zoom_old_webinar_products(){

    //we want to only run this once per a day
    $transient_name = 'old_zoom_webinar_check';
    
    //check if transient doesn't exist i.e. run
    if(!get_transient($transient_name)){

        //set the transient to prevent anything further happening
        set_transient($transient_name, 'RAN', 1*DAY_IN_SECONDS);

        //check the users setting
        $setting = get_option('wc_settings_zoom_old_webinar_products');

        //only continue if we need to take an action
        if(isset($setting) && $setting != 'nothing'){

            //get webinars
            //only continue if authenticated
            $webinar_data = array();
            if(get_option('wc_settings_zoom_refresh_token')){

                $url = woocommerce_to_zoom_get_api_base().'users/me/webinars?page_size=300';

                $response = wp_remote_get( $url, array(
                    'headers' => array(
                        'Authorization' => 'Bearer '.woocommerce_to_zoom_get_access_token(),
                    )
                ));

                $status = wp_remote_retrieve_response_code( $response );

                if($status == 200){
                    $decodedBody = json_decode(preg_replace('/("\w+"):(\d+(\.\d+)?)/', '\\1:"\\2"', $response['body']), true);
                    $webinars = $decodedBody['webinars'];
                    foreach($webinars as $webinar){

                        $webinar_start_timestamp = strtotime($webinar['start_time']);
                        $webinar_id = $webinar['id'];
                        $webinar_data[$webinar_id] = $webinar_start_timestamp;
                       
                    }
                }
            }

            //only continue if we have data
            if(count($webinar_data)>0){

                //now we need to loop through the products and check if they have a webinar id
                $args = array( 
                    'post_type' => 'product', 
                    'posts_per_page' => -1,
                    'post_status' => 'publish', 
                );
                
                $products = get_posts( $args ); 

                //only continue if products exist
                if($products){
                    foreach($products as $product){
                        $product_id = $product->ID;
                        $webinar_id = get_post_meta( $product_id, 'zoom_webinar_selection', true );
                        $webinar_start_time = $webinar_data[$webinar_id];

                        //check to see if webinar id exists
                        if(strlen($webinar_id)>0 && strlen($webinar_start_time)>0){

                            //get the wordpress start time
                            $current_time = current_time( 'timestamp' );

                            //check time
                            if($current_time > $webinar_start_time){
                                //do actions
                                //do draft
                                if($setting == 'draft'){
                                    wp_update_post(array(
                                        'ID'    =>  $product_id,
                                        'post_status'   =>  'draft'
                                    ));
                                }
                                //do delete
                                if($setting == 'delete'){
                                    wp_trash_post( $product_id ); 
                                }


                            } //end check of time
                        } //end check if webinar id exists
                    } //end for each product
                } //end check if products exist
            } //end check of webinar data exists
        } //end check if user setting is relevant
    } //end transient check
}

?>