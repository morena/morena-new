jQuery(document).ready(function ($) {

    function validateEmail(email) {
        var re = /\S+@\S+\.\S+/;
        return re.test(email);
    }

    $('body').on('click','.webinar-agenda-icon', function(event){

        var agenda = $(this).next();

        if(agenda.css('display') == 'none'){
            agenda.css('display','block');  
        } else {
            agenda.css('display','none');      
        }

        // $(this).next().toggle();

    });


    $('body').on('click','.zoom-registration-form-submit', function(event){

        event.preventDefault();

        //remove previous submit errors
        $('.zoom-registration-form-submit').removeClass('zoom-required-error');


        //we first need to check for required fields
        var errorsFound = 0;


        $('.zoom-required-field').each(function( index ) {

            var fieldValue = $(this).find('input,select').val();

            if(fieldValue.length < 1){
                errorsFound++;

                $(this).find('input,select').addClass('zoom-required-error');

            } else {
                $(this).find('input,select').removeClass('zoom-required-error');   
            }

            var fieldName = $(this).find('input,select').attr('name');

            if(fieldName == 'email'){
                if(validateEmail(fieldValue)){
                    $(this).find('input,select').removeClass('zoom-required-error'); 
                } else {
                    errorsFound++;
                    $(this).find('input,select').addClass('zoom-required-error');
                }
            }

            //also validate email
            
        });

        console.log(errorsFound);

        if(errorsFound == 0){

            //continue

            //add loading
            var originalText = $(this).text();
            $(this).text($(this).attr('data-waiting'));
            

            var webinarId = $(this).attr('data-webinar-id');


            //do standard answers
            var answers = new Object();

            $('.zoom-registration-field-standard').each(function( index ) {

                var name = $(this).attr('name');
                var answer = $(this).val();
                answers[name] = answer;

            });

            //do custom answer
            var customAnswers = [];

            $('.zoom-registration-field-custom').each(function( index ) {

                var name = $(this).attr('name');
                var answer = $(this).val();
                
                var tempObject = {title:name, value:answer};
                customAnswers.push(tempObject);

            });

            // console.log(customAnswers);

            //now lets add the custom answers to the main object
            answers['custom_questions'] = customAnswers;

            var json = JSON.stringify(answers);

            console.log(answers);
            console.log(json);
            
            //do ajax call
            var data = {
                'action': 'zoom_register_user',
                'webinarId': webinarId,
                'json': json,
            }; 
    
            jQuery.ajax({
            url: zoom_register_user.ajaxurl,
            type: "POST",
            data: data,
            })
            .done(function(data, textStatus, jqXHR) {

                if(data != 'ERROR'){
                    window.location.href = data;
                } else {
                    $('.zoom-registration-form-submit').addClass('zoom-required-error');
                }
             
                $('.zoom-registration-form-submit').text(originalText);

            });

        }
        

    });

});