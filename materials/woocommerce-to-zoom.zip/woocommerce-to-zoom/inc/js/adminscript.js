jQuery(document).ready(function ($) {




    //during the authorisation process get the code and send it to php

    //this function can find a parameter in a query string
    function getParameterByName(name, url) {
            if (!url) url = window.location.href;
            name = name.replace(/[\[\]]/g, "\\$&");
            var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
                results = regex.exec(url);
            if (!results) return null;
            if (!results[2]) return '';
            return decodeURIComponent(results[2].replace(/\+/g, " "));
    }
    var code = getParameterByName('code');
    var authenticate = getParameterByName('authenticate');
    var tab = getParameterByName('tab');
    // var realmId = getParameterByName('realmId');

    if (code != null && authenticate != 'false' && tab == 'zoom') {
    
        alertify.log("Please wait while we complete the connection...");

        var data = {
                    'action': 'save_authentication_details_zoom',
                    'code': code,
                    // 'realmId': realmId,
                    };


        jQuery.post(ajaxurl, data, function (response) {
            
           console.log(response);
            
            if(response == 200){
                
                alertify.success('The connection has now been completed'); 

                var currentUrl = window.location.href;

                currentUrl += '&authenticate=false'

                window.location.replace(currentUrl);


            } else {
                alertify.error('There\'s been some kind of error, please try again. If the error persists please contact support.');        
            }
            
        });   
        
    }




    //disconnect
    $('body').on('click','.disconnect-from-zoom', function(event){

        event.preventDefault();
        event.stopPropagation();

        alertify.log("Please wait while we disconnect...");


        var data = {
            'action': 'zoom_webinars_disconnect',
        };

        jQuery.post(ajaxurl, data, function (response) {
            
            console.log('Complete');
            alertify.success('You have been disconnected.');
            location.reload();
            
        });

        return false;

    });




    //do manual sync
    $('.wrap').on("click","#create-zoom-registrants", function(event){

        event.preventDefault();
        event.stopPropagation();

        alertify.log("Please wait while we sync the order...");

        var order_id = $(this).attr('data');

        var data = {
            'action': 'zoom_webinars_process_shop_order',
            'order_id': order_id,
        };


        jQuery.post(ajaxurl, data, function (response) {
            
            console.log('Complete');
            alertify.success('The order has been synced');
            location.reload();
            
        });

        return false;

    });




    //clear transients
    $('body').on('click','#clear-zoom-transients', function(event){

        event.preventDefault();
        // event.stopPropagation();

        alertify.log("Please wait while we clear the cache...");


        var data = {
            'action': 'zoom_webinars_clear_transients',
        };

        jQuery.post(ajaxurl, data, function (response) {
            
            console.log('Complete');
            alertify.success('The cache has been cleared');
            // location.reload();
            
        });

        return false;

    });


    //expand faq
    $('body').on('click','.faq-container-webinars .question', function(event){

        $(this).next().toggle();

        if($(this).next().css('display') == 'block'){
            $(this).find('span').removeClass('dashicons-plus').addClass('dashicons-minus');
        } else {
            $(this).find('span').removeClass('dashicons-minus').addClass('dashicons-plus');
        }

    });

    //move the faq to below settings
    if($('.faq-container-webinars').length){
        $('.faq-container').insertAfter('.submit');
    }


    function update_webinar_list_option(){


        var items = [];

        $('.multiple-selection-list li').each(function( index ) {
            var selectItemValue = $(this).find('select').val();
            // console.log(selectItemValue);
            
            if(selectItemValue.length>0){

                //only add items to array if not already in array
                if(!items.includes(selectItemValue)){
                    items.push(selectItemValue);
                }
                
            }
    
        });


        //add the items to the option
        var itemsToCommaList = items.join(',');

        $('.zoom_webinar_selection_field input').val(itemsToCommaList);

    }


    //when clicking the minus icon remove the row item
    $('body').on('click','.multiple-selection-list .dashicons-minus', function(event){
        $(this).parent().remove();
        update_webinar_list_option();   
    });

    $('body').on('click','.multiple-selection-list .dashicons-plus', function(event){

        var thisRowItem = $(this).parent();
        var thisRowItemClone = thisRowItem.clone();

        //set the new row select to blank
        thisRowItemClone.find('select').val('');

        thisRowItem.after( thisRowItemClone );

        // $('.multiple-selection-list').append(thisRowItem);

        

        update_webinar_list_option();   
    });

    //on change of select values
    $('body').on('change','.multiple-selection-list select', function(event){
        update_webinar_list_option();   
    });
    
    //make list sortable
    if($('.multiple-selection-list').length){
        $( '.multiple-selection-list' ).sortable({
            stop : function(event,ui){ update_webinar_list_option();   }
        });
    }
    
    


});    