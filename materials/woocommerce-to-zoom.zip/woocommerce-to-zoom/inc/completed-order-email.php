<?php
    add_action( 'woocommerce_email_order_details', 'woocommerce_to_zoom_completed_order_email', 20, 4 );
    function woocommerce_to_zoom_completed_order_email( $order, $sent_to_admin = false, $plain_text = false, $email = '' ) {

        //only run if enabled in the plugin settings
        $completed_order_email_enabled = get_option('wc_settings_zoom_enable_completed_order_email');

        if(isset($completed_order_email_enabled) && $completed_order_email_enabled == 'yes' && $email->get_title() == 'Completed order'){

            //start output
            $html = '';

            $order_id = $order->get_id();

            //do some logging to try and sort our sequencing issue i.e. people not showing on this email despite being registered
            //that is, this email might be getting sent before people are registered
            $logger = wc_get_logger();
            $context = array( 'source' => 'woocommerce-to-zoom' );
            $logger->info( 'COMPLETED ORDER EMAIL SENT FOR ORDER ID: '.$order_id, $context );

            if(get_post_meta($order_id,'zoom_registrant_ids',false)){

                $registrants = get_post_meta($order_id,'zoom_registrant_ids',true);
                
                $html .= '<h2>'.__('Webinar registrants','woocommerce-to-zoom').'</h2>';

                $html .= '<ul style="list-style: inherit; margin-bottom: 40px;">';
        
                foreach($registrants as $key => $value){
                    $html .= '<li data="'.$key.'">';
                        $html .= '<strong>'.$value['first_name'].' '.$value['last_name'].'</strong> ('.$value['email'].') - <a target="_blank" href="'.$value['join_url'].'">'.__('Join link','woocommerce-to-zoom').'</a>';
                    $html .= '</li>';
                }
                $html .= '</ul>';
        
            }

            echo $html;
        }
    }

    
?>