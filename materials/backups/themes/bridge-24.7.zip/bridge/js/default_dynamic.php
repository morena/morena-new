<?php
do_action( 'bridge_qode_action_default_dynamic' );