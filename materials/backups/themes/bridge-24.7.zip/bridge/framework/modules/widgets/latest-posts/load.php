<?php
include_once QODE_FRAMEWORK_MODULES_ROOT_DIR . '/widgets/latest-posts/latest-posts.php';
include_once QODE_FRAMEWORK_MODULES_ROOT_DIR . '/widgets/latest-posts/functions.php';
