<?php

include_once QODE_FRAMEWORK_MODULES_ROOT_DIR . '/welcome/welcome.php';