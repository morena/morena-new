<?php

include_once QODE_FRAMEWORK_MODULES_ROOT_DIR . '/widgets/social-icon/social-icon.php';
include_once QODE_FRAMEWORK_MODULES_ROOT_DIR . '/widgets/social-icon/functions.php';