<?php

include_once QODE_FRAMEWORK_MODULES_ROOT_DIR . '/widgets/related-posts/related-posts.php';
include_once QODE_FRAMEWORK_MODULES_ROOT_DIR . '/widgets/related-posts/functions.php';