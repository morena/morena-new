<?php

include_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/panel-area/custom-styles/panel-area.php';